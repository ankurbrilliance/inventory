import React, { useState, useEffect } from "react";
import { Container, Col, Row } from "react-bootstrap";
import { useParams } from "react-router-dom";
import Axios from "axios";

const BillingMore = () => {
  const { id } = useParams();

  const fetchData = async () => {};

  useEffect(() => {
    fetchData();
  });

  return (
    <>
      <Container
        style={{ backgroundColor: "grey" }}
        className="col-xl-6 col-lg-6 col-md-6 col-sm-6 p-auto"
      >
        <Container
          style={{
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Row>
            <Col className="col-xl-3 col-lg-3 col-md-3 col-sm-3">firmName</Col>
            <Col className="col-xl-1 col-lg-1 col-md-1 col-sm-1">-</Col>
            <Col className="col-xl-7 col-lg-7 col-md-7 col-sm-7">
              Brilliance
            </Col>
          </Row>
          <Row>
            <Col className="col-xl-3 col-lg-3 col-md-3 col-sm-3">firmName</Col>
            <Col className="col-xl-1 col-lg-1 col-md-1 col-sm-1">-</Col>
            <Col className="col-xl-7 col-lg-7 col-md-7 col-sm-7">
              Brilliance
            </Col>
          </Row>
          <Row>
            <Col className="col-xl-3 col-lg-3 col-md-3 col-sm-3">firmName</Col>
            <Col className="col-xl-1 col-lg-1 col-md-1 col-sm-1">-</Col>
            <Col className="col-xl-7 col-lg-7 col-md-7 col-sm-7">
              Brilliance
            </Col>
          </Row>
          <Row>
            <Col className="col-xl-3 col-lg-3 col-md-3 col-sm-3">firmName</Col>
            <Col className="col-xl-1 col-lg-1 col-md-1 col-sm-1">-</Col>
            <Col className="col-xl-7 col-lg-7 col-md-7 col-sm-7">
              Brilliance
            </Col>
          </Row>
        </Container>
      </Container>
    </>
  );
};

export default BillingMore;
